=================================================================================================================================================


				Thanks for purchasing Symphonies Template !

					     Source by H2M_Dev


==================================================================================================================================================

How to configure this template step by step:
What you need:

-a website
-a database

So let's go:

0)Change your PHP version to 5.6 !
1)Transfer all files to your website.
2)go to /include/settings.php and configure the database settings.
3)Go to your database, log and select your DB, then click "import" button and import the "DataBase.sql" file.
4)Then, go to your website and connect with : username = admin and password = password
5)Go to "Settings" and change your password, VERY IMPORTANT !!!
6)Go to your paypal account > Profile > My Selling Tools > Instant Payment Notification > Update > and then put this : http://www.YourSiteName.com/ipn/index.php

Extra: To set an admin, go to Administration > Users and press Edit then you put "Admin" instead of "Member".



Any question? Any bugs ? contact me : twitter: @H2M_Dev